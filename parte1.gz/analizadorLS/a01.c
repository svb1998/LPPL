// Ejemplo de uso: operadores de incremento y decremento
//------------------------------------------------------
int main ()
{ int x; int y;

  x = 4;
  y = ++x; print(x); print(y);
  y = x++; print(x); print(y);

  y = x--; print(x); print(y); 
  y = --x; print(x); print(y); 

  return 0;
} 
